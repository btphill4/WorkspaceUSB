package activity3;

public class Task {

	public static void main(String[] args)
	{
		System.out.println("Activty 3 : Priority Tester\n");
		
		Priority a = new Priority(2);
		Priority b = new Priority(0);
		
		System.out.println("Priority a :" + a.getPriority());
		System.out.println("Priority b :" + b.getPriority());
		
		a.setPriority(3);
		b.setPriority(1);
		
		System.out.println();
		System.out.println(a.toString());
		System.out.println(b.toString());
		

	}

}
