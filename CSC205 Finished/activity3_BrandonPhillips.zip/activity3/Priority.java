package activity3;

public class Priority 
{
	public int priority;
	public String levels;
	
	//Methods
	public Priority()
	{
		priority = 0;
	}
	public Priority(int newPriority)
	{
		priority = newPriority;
	}
	
	public void setPriority(int level)
	{
		priority = level;
	}
	
	public String getPriority()
	{
		if (priority == 0)
			levels = " no priority";
		if (priority == 1)
			levels = " low priority";
		if (priority == 2)
			levels = " medium priority";
		if (priority == 3)
			levels = " high priority";
		
		return levels;
		
	}
	
	public String toString()
	{
		return "The object has: " + getPriority();
	}
	
}
