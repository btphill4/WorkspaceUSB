package acvitivies;

public class Deck {

	public static void main(String[] args) 
	{
		for (int num = 1;num <= 5; num++) //prints out the deck 5 times
		{
		Cards deck = new Cards();
		deck.toString();
		}

	}

}
