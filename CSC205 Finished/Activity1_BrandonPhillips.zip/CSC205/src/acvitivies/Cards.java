//Brandon Phillips

package acvitivies;
import java.util.Random;

public class Cards 
{

	//public static void main(String[] args) 
	//{
		Random generator = new Random();
		/*
		public final static int hearts = 0, spades = 1, clubs = 2, diamonds = 3;
		public final static int ace = 1, jack = 11, queen = 12, king = 13;
	*/
		public int suit; 
		public int face;
		public int randomSuits = generator.nextInt(3);
	    public int randomFace = generator.nextInt(13);
	    
		//Class methods
		//Constructor
		public Cards() 
		{
			suit = randomSuits;
			face = randomFace;
		}

		public Cards(int cardFace, int cardSuit)
		{
			face = cardFace;
			suit = cardSuit;
		}
		
		//getters
		public int getSuit()
		{
			return suit;
		}
		
		public int getFace()
		{
			return face;
		}
		
		public String getSuitAsString() 
		{
	        switch ( suit ) 
	        {
	           case 0:   
	        	   return "Spades";
	           case 1:   
	        	   return "Hearts";
	           case 2: 
	        	   return "Diamonds";
	           case 3:   
	        	   return "Clubs";
	           default: 	  
	        	   return "default";
	        }
		}
		
	       
	      public String getFaceAsString() 
	      { 
	    	switch(face)
			  { 
			  case 1: 
			  	return "ace"; 
			  case 2: 
			  	return "2";
			  case 3: 
			  	return "3";
			  	
			  case 4: 
			  	return "4";
			  	
			  case 5: 
			  	return "5";
			  
			  case 6: 
			  	return "6";
			  	
			  case 7: 
			  	return "7";
			  	
			  case 8: 
			  	return "8";
			  	
			  case 9:
			  	return "9";
			  
			  case 10: 
			  	return "10";
			  
			  case 11:
			  	return "jack";
			  	
			  case 12: 
			  	return "queen";
			  	
			  case 13: 
			  	return "king";
			  		  
			  default: 
				  return "default";
			
			   }
	      }
        
        public String toString() {
         
        System.out.println(getFaceAsString() + " of " + getSuitAsString());
        return getFaceAsString() + " of " + getSuitAsString();
        }
		
		
		
		
		
		
		
	/*	
		//for loop to select multiple cards
		for (int num = 1;num <= 5; num++)
	{	
		//generate the suit of each card
		suit = generator.nextInt(4) + 1;
		
		//Takes the number and applies it to a suit
		{  switch(suit)
			  { 
			  case 1: suit = 1;
			  	suit1 = "hearts";
			  	break;
			  case 2: suit = 2;
			  	suit1 = "spades";
			  	break;
			  case 3: suit = 3;
			  	suit1 = "clubs";
			  	break;
			  case 4: suit = 4;
			  	suit1 = "diamonds";
			  	break;
			  }
		}
		//Generates the face of each card
		face = generator.nextInt(13) + 1;
				
		//Takes the number and gives each card a face
		{  switch(face)
			  { 
			  case 1: face = 1;
			  	face1 = "ace"; 
			  	break;
			  case 2: face = 2;
			  	face1 = "2";
			  	break;
			  case 3: face = 3;
			  	face1 = "3";
			  	break;
			  case 4: face = 4;
			  	face1 = "4";
			  	break;
			  case 5: face = 5;
			  	face1 = "5";
			  	break;
			  case 6: face = 6;
			  	face1 = "6";
			  	break;
			  case 7: face = 7;
			  	face1 = "7";
			  	break;
			  case 8: face = 8;
			  	face1 = "8";
			  	break;
			  case 9: face = 9;
			  	face1 = "9";
			  	break;
			  case 10: face = 10;
			  	face1 = "10";
			  	break;
			  case 11: face = 11;
			  	face1 = "jack";
			  	break;
			  case 12: face = 12;
			  	face1 = "queen";
			  	break;
			  case 13: face = 13;
			  	face1 = "king";
			  	break;
			  }
		}
		 //Display card chosen from deck
		 System.out.println("You have selected the " + face1 + " of " + suit1);
		} 
	}
	*/
}


