package activity2;
import java.util.Scanner;

/**
 * Driver class for CSC205 Activity 2
 * 
 * @author Wade Huber
 *
 */
public class Activity2 {

	public static void main(String[] args) {

		Fraction n = new Fraction(8,0);
		
		Scanner scan = new Scanner(System.in);
		
	do {
		System.out.print ("Enter the numerator:  ");
			n.setNumerator(scan.nextInt());	
		System.out.print ("Enter the denominator:  ");
		
		try
		{
		n.setDenominator(scan.nextInt());	
		}	
		catch (ArithmeticException e)
		{
			System.out.println("Arithmetic Exception");
		}
		
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
	} while (n.getDenominator() == 0);
		
		if (n.getDenominator() != 0)
		{
		System.out.println ("The fraction " + n.getNumerator() + "/" +
				n.getDenominator() + " is equal to " + n.toMixedNumber());
		}
		scan.close();

	}
}