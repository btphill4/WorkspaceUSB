package geometry205;

public abstract class Shapes
{
	public abstract double getArea();
	public abstract double getPerimeter();

}
